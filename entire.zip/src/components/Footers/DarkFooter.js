/*eslint-disable*/
import React from "react";

// reactstrap components
import { Container, Button } from "reactstrap";


function DarkFooter() {
  return (
    <footer className="footer" data-background-color="info" style={{backgroundColor:"#2ca8ff"}}>
      <Container>
        <nav>
          <ul>
            <li>
              <a href="/index"
                
              >
                Home
              </a>
            </li>
            <li>
              <a href="/landing-page"
            
              >
                About Us
              </a>
            </li>
          </ul>
        </nav>
        <div className="copyright" id="copyright">
            <i className="fa fa-phone"></i> Phone: +441 173 282 636 <br/><i className="fa fa-envelope"></i> Email: Kamran2.Munir@uwe.ac.uk <br></br>
            <i className="fa fa-map-marker"></i> University of the West of England - UWE Bristol
        </div>
      </Container>
      
    </footer>
  );
}

export default DarkFooter;

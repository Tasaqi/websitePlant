/*eslint-disable*/
import React from "react";

// reactstrap components
import { Container } from "reactstrap";

// core components

function DefaultFooter() {
  return (
    <>
      <footer className="footer footer-default">
        <Container>
          <nav>
            <ul>
              <li>
                <a
                  to="/index"
                  target="_blank"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  to="/landing-page"
                  target="_blank"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  to="/profile-page"
                  target="_blank"
                >
                  Web App
                </a>
              </li>
            </ul>
          </nav>
          <div className="copyright" id="copyright">
            © {new Date().getFullYear()}, Designed by{" "}
            <a
              href="#"
              target="_blank"
            >
              House of Technology
            </a>
            . Coded by{" "}
            <a
              href="#"
              target="_blank"
            >
             House of Technology
            </a>
            .
          </div>
        </Container>
      </footer>
    </>
  );
}

export default DefaultFooter;

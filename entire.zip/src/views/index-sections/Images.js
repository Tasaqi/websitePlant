import React from "react";

// reactstrap components
import { Container, Row, Col } from "reactstrap";

// core components

function Images() {
  return (
    <>
      <div className="section section-images">
        <Container>
          <Row>
            <Col md="4">
            <img
                  alt="..."
                  src={require("assets/img/hero-image-3.png")}
            ></img>
            </Col>
            <Col md="8">
              <h2>The mobile crop doctor for your pocket</h2>
              <p> Improve your profitability with the latest technologies and globally pooled farming know-how. If you are a farmer, agricultural worker or consultant, Plantix is your reliable partner for best practices in agriculture, disease control, and yielding better crops</p>
              
              <Row>
                <Col md="2">
                
                    <i style={{fontSize:50, padding:30}} className="now-ui-icons media-1_camera-compact"></i> 
                    <i style={{fontSize:50, padding:30}} className="now-ui-icons design_image"></i>
                    <i style={{fontSize:50, padding:30}} className="now-ui-icons gestures_tap-01"></i>
                    <i style={{fontSize:50, padding:30}} className="now-ui-icons media-2_sound-wave"></i>
                </Col>
                <Col md="10">
                <div  style={{ padding:10}}>
                    <p> Take a picture of your arable crop by using a simple 3G-enabled smartphone. Smart Agro analyzes it within the blink of an eye and reports detailed information about the plant's species and its potential disease</p>
                </div>
                <div style={{ padding:10}}>
                <p>Get in touch with a community of scientists, farmers and plant experts to exchange information about plant issues on a local or global level</p>
                </div>
                <div style={{ padding:10}}>
                  <p>This is the third pillar for multiplying your farming expertise. The Crop Advisory is a holistic tool that reminds you about all the steps necessary for the highest yields and best quality of your farm produce</p>
                </div>
                <div style={{ paddingLeft:10, paddingTop:20}}>
                  <p>Smart Agro provides the largest independent database for plant problems and their treatments</p>
                </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}

export default Images;




 {/* <div className="hero-images-container">
                <img
                  alt="..."
                  src={require("assets/img/hero-image-1.png")}
                ></img>
              </div>
              <div className="hero-images-container-1">
                <img
                  alt="..."
                  src={require("assets/img/hero-image-2.png")}
                ></img>
              </div>
              <div className="hero-images-container-2">
                <img
                  alt="..."
                  src={require("assets/img/hero-image-3.png")}
                ></img>
              </div> */}
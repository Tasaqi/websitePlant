import React from "react";

// reactstrap components
import {
  Button,
  Input,
  InputGroupAddon,
  InputGroupText,
  InputGroup,
  Container,
  Row,
  Col,
  UncontrolledTooltip
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar";
import LandingPageHeader from "components/Headers/LandingPageHeader.js";
import DefaultFooter from "components/Footers/DefaultFooter.js";
import DarkFooter from "components/Footers/DarkFooter";

function LandingPage() {
  const [firstFocus, setFirstFocus] = React.useState(false);
  const [lastFocus, setLastFocus] = React.useState(false);
  React.useEffect(() => {
    document.body.classList.add("landing-page");
    document.body.classList.add("sidebar-collapse");
    document.documentElement.classList.remove("nav-open");
    return function cleanup() {
      document.body.classList.remove("landing-page");
      document.body.classList.remove("sidebar-collapse");
    };
  });
  return (
    <>
      <IndexNavbar />
      <div className="wrapper">
        <LandingPageHeader />

        <div className="section section-team text-center">
          <Container>
            <h2 className="title">Here is our team</h2>
            <div className="team">
              <Row>
                
              <Col md="6">
                  <div className="team-player">
                    <img
                      alt="..."
                      className="rounded-circle img-fluid img-raised"
                      src={require("assets/img/kamran.jpg")}
                    ></img>
                    <h4 className="title">Dr. Kamran Munir</h4>
                    <p className="category text-info">Associate Professor</p>
                    <p>
                    Dr Kamran Munir is Associate Professor in Data Science, in the Department of Computer Science and Creative Technologies. Dr. Munir's research projects are in the areas of Data Science, Big Data and Analytics, Artificial Intelligence and Virtual Reality mainly funded by the European Commission (EC), Innovate UK and British Council.
                    </p>
                    <Button
                      className="btn-round"
                      color="info"
                      id="call-prompt"
                      href="#mailto:Kamran2.Munir@uwe.ac.uk"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-phone"></i>
                    </Button>
                    <UncontrolledTooltip target="#call-prompt">
                    Contact # +441 173 282 636
                </UncontrolledTooltip>
                    <Button
                      className=" btn-round"
                      color="info"
                      onClick={e => window.open("https://people.uwe.ac.uk/Person/Kamran2Munir","_blank")}
                    >
                      <i className="fa fa-info-circle"></i>
                    </Button>
                    <Button
                      className="btn-round"
                      color="info"
                      onClick={e => window.open("https://www.facebook.com/kamran.munir","_blank")}
                    >
                      <i className="fab fa-facebook"></i>
                    </Button>
                    <Button
                      className="btn-round"
                      color="info"
                      id="email-prompt"
                      href="#mailto:Kamran2.Munir@uwe.ac.uk"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-envelope"></i>
                    </Button>
                    <UncontrolledTooltip target="#email-prompt">
                      Email: Kamran2.Munir@uwe.ac.uk
                </UncontrolledTooltip>
                <Button
                      className="btn-round"
                      color="info"
                      id="address-prompt"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-address-card"></i>
                    </Button>
                    <UncontrolledTooltip target="#address-prompt">
                      Department of Computer Science and Creative Technologies, University of the West of England (UWE Bristol)
                </UncontrolledTooltip>
                  </div>
                </Col>
                <Col md="6">
                  <div className="team-player">
                    <img
                      alt="..."
                      className="rounded-circle img-fluid img-raised"
                      src={require("assets/img/imag1.jpg")}
                    ></img>
                    <h4 className="title">Dr. Mubeen Ghafoor</h4>
                    <p className="category text-info">Research Fellow</p>
                    <p>
                    He has vast research and industrial experience in the field of Data Sciences, Mobile App Development, Image Processing, Machine Vision Systems,
                    Biometrics Systems, Signal Analysis, GPU based hardware design and Software implementation.{" "}
                    </p>
                    <Button
                      className="btn-round"
                      color="info"
                      id="call-prompt2"
                      href="#mailto:mubeenghafoor@yahoo.com"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-phone"></i>
                    </Button>
                    <UncontrolledTooltip target="#call-prompt2">
                    Contact # +92 344 528 9102
                </UncontrolledTooltip>
                    <Button
                      className=" btn-round"
                      color="info"
                      onClick={e => window.open("http://houseoftechnology.com.pk/","_blank")}
                    >
                      <i className="fa fa-info-circle"></i>
                    </Button>
                    <Button
                      className="btn-round"
                      color="info"
                      onClick={e => window.open("https://www.facebook.com/profile.php?id=100010044639996","_blank")}
                    >
                      <i className="fab fa-facebook"></i>
                    </Button>
                    <Button
                      className="btn-round"
                      color="info"
                      id="email-prompt2"
                      href="#mailto:mubeenghafoor@yahoo.com"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-envelope"></i>
                    </Button>
                    <UncontrolledTooltip target="#email-prompt2">
                      Email: mubeenghafoor@yahoo.com
                </UncontrolledTooltip>
                <Button
                      className="btn-round"
                      color="info"
                      id="address-prompt2"
                      onClick={e => e.preventDefault()}
                    >
                      <i className="fa fa-address-card"></i>
                    </Button>
                    <UncontrolledTooltip target="#address-prompt2">
                    Cubator 1ne, Office # 007, Park Road, Chak Shahzad, Islamabad, Pakistan.
                </UncontrolledTooltip>
                  </div>
                </Col>
              </Row>
            </div>
          </Container>
        </div>
        <div className="section section-contact-us text-center">
          <Container>
            <h2 className="title">Want to work with us?</h2>
            <p className="description">Your project is very important to us.</p>
            <Row>
              <Col className="text-center ml-auto mr-auto" lg="6" md="8">
                <InputGroup
                  className={
                    "input-lg" + (firstFocus ? " input-group-focus" : "")
                  }
                >
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="now-ui-icons users_circle-08"></i>
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="First Name..."
                    type="text"
                    onFocus={() => setFirstFocus(true)}
                    onBlur={() => setFirstFocus(false)}
                  ></Input>
                </InputGroup>
                <InputGroup
                  className={
                    "input-lg" + (lastFocus ? " input-group-focus" : "")
                  }
                >
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="now-ui-icons ui-1_email-85"></i>
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Email..."
                    type="text"
                    onFocus={() => setLastFocus(true)}
                    onBlur={() => setLastFocus(false)}
                  ></Input>
                </InputGroup>
                <div className="textarea-container">
                  <Input
                    cols="80"
                    name="name"
                    placeholder="Type a message..."
                    rows="4"
                    type="textarea"
                  ></Input>
                </div>
                <div className="send-button">
                  <Button
                    block
                    className="btn-round"
                    color="info"
                    href="#pablo"
                    onClick={e => e.preventDefault()}
                    size="lg"
                  >
                    Send Message
                  </Button>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
        


        <DarkFooter />
      </div>
    </>
  );
}

export default LandingPage;
